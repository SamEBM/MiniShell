#!/bin/bash
#autor: Samuel Miranda
gcc -o SHELL minishell.c
./SHELL